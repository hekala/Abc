﻿namespace Abc.Facade.Common
{
    public abstract class DefinedView: NamedView
    {
        public string Definition { get; set; }
    }
}