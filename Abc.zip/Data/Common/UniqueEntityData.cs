﻿namespace Abc.Data.Common
{
    public class UniqueEntityData: PeriodData
    {
        public string Id { get; set; }
    }
}