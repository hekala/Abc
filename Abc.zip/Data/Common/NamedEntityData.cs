﻿namespace Abc.Data.Common
{
    public class NamedEntityData: UniqueEntityData
    {
        public string Name { get; set; }
        public string Code { get; set; }
    }
}