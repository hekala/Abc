﻿using Abc.Data.Common;

namespace Abc.Data.Money
{
    public class CurrencyData: DefinedEntityData
    {
    }
}
