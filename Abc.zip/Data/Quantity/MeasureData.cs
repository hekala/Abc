﻿using Abc.Data.Common;

namespace Abc.Data.Quantity
{
    public class MeasureData: DefinedEntityData
    {
    }
}
