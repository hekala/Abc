﻿namespace Abc.Domain.Common
{
    public interface ISearching
    {
        string SearchString { get; set; }
    }
}