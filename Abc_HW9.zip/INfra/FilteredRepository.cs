﻿using System;
using System.Linq;
using System.Linq.Expressions;
using Abc.Data.Common;
using Abc.Domain.Common;
using Microsoft.EntityFrameworkCore;

namespace Abc.Infra
{
    public abstract class FilteredRepository<TDomain, TData>: SortedRepository<TDomain, TData>, IFiltering
        where TData: PeriodData, new()
        where TDomain: Entity<TData>, new()
    {
        public string SearchString { get; set; }
        public string FixedFilter { get; set; }
        public string FixedValue { get; set; }

        protected FilteredRepository(DbContext c, DbSet<TData> s) : base(c, s) { } 
        
        protected internal override IQueryable<TData> createSqlQuery() //overrideib baserep meetodi, nagu sortedRep!
        {
            var query = base.createSqlQuery();
            query = addFixedFiltering(query); 
            query = addFiltering(query); //lisab filtri

            return query; //annab tagasi koos filtriga
        }

        internal IQueryable<TData> addFixedFiltering(IQueryable<TData> query)
        {
            var expression = createFixedWhereExpression();
            return (expression is null)? query: query.Where(expression);
        }

        internal Expression<Func<TData, bool>> createFixedWhereExpression()
        {
            if (string.IsNullOrWhiteSpace(FixedValue)) return null;
            if (string.IsNullOrWhiteSpace(FixedFilter)) return null;
            var param = Expression.Parameter(typeof(TData), "s");

            var p = typeof(TData).GetProperty(FixedFilter);

            if (p is null) return null; //kui filtrit pole siis midagi
            Expression body = Expression.Property(param, p);
            if (p.PropertyType != typeof(string)) //otsib property
                body = Expression.Call(body, "ToString", null); //tostring meetod teeb stringiks kui pole string
            body = Expression.Call(body, "Contains", null, Expression.Constant(FixedValue)); //rakendab contains meetod
            var predicate = body;
            
            return Expression.Lambda<Func<TData, bool>>(predicate, param);
        }

        internal IQueryable<TData> addFiltering(IQueryable<TData> query)
        {
            if (string.IsNullOrEmpty(SearchString)) return query;
            var expression = createWhereExpression();
            return expression is null ? query : query.Where(expression);
        }

        internal Expression<Func<TData, bool>> createWhereExpression()
        {
            if (string.IsNullOrWhiteSpace(SearchString)) return null;
            var param = Expression.Parameter(typeof(TData), "s"); //millisest tuubist hakkad lambdaexp tegema
            
            Expression predicate = null;

            foreach (var p in typeof(TData).GetProperties())
            {
                Expression body = Expression.Property(param, p);
                if (p.PropertyType != typeof(string)) //otsib property
                    body = Expression.Call(body, "ToString", null); //tostring meetod teeb stringiks kui pole string
                body = Expression.Call(body, "Contains", null, Expression.Constant(SearchString)); //rakendab contains meetod
                predicate = predicate is null ? body : Expression.Or(predicate, body);
            }

            return predicate is null ? null : Expression.Lambda<Func<TData, bool>>(predicate, param);
        }
    }
}