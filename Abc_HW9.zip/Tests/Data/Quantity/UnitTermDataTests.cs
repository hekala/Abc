﻿using Abc.Data.Quantity;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Abc.Tests.Data.Quantity
{
    [TestClass]
    public class UnitTermDataTests: SealedClassTests<UnitTermData, CommonTermData>
    {
    }
}
