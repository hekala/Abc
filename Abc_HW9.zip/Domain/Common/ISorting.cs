﻿namespace Abc.Domain.Common
{
    public interface ISorting
    {
        string SortOrder { get; set; }
    }
}