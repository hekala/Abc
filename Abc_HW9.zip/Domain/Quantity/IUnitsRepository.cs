﻿using Abc.Domain.Common;

namespace Abc.Domain.Quantity
{
    public interface IUnitsRepository : IRepository<Unit> { }
}
