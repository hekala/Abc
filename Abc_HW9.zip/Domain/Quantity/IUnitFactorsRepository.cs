﻿using Abc.Domain.Common;

namespace Abc.Domain.Quantity
{
    public interface IUnitFactorsRepository: IRepository<UnitFactor> { }
}
