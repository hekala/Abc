﻿namespace Abc.Data.Quantity
{
    public sealed class UnitTermData: CommonTermData
    {
    }
}
